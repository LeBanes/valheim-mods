Valheim mod pack v2.1 contents:
*   NEW: Better Wisplight: https://www.nexusmods.com/valheim/mods/2103
*   UPDATED: Better Trader Remake: https://valheim.thunderstore.io/package/Digitalroot/Better_Trader_Remake/

-   Forsaken Powers Plus: https://www.nexusmods.com/valheim/mods/2067
-   Timed Torches Stay Lit: https://www.nexusmods.com/valheim/mods/2034
-   FirstPersonMode: https://valheim.thunderstore.io/package/Azumatt/FirstPersonMode/
-   Equipment and Quick Slots: https://www.nexusmods.com/valheim/mods/92
-   Plant Everything: https://www.nexusmods.com/valheim/mods/1042
-   Plant Easily: https://www.nexusmods.com/valheim/mods/2350
-   Real Clock Mod: https://www.nexusmods.com/valheim/mods/489

To install:
-   Insert this BepInEx folder into your Steam\steamapps\common\Valheim directory.
-   Replace any duplicate files as prompted.